#include<stdlib.h>

#ifndef UNTITLED1_FUNCTION_FILE_NAME_H
#define UNTITLED1_FUNCTION_FILE_NAME_H

int digit_sum(unsigned int d);

#endif //UNTITLED1_FUNCTION_FILE_NAME_H
